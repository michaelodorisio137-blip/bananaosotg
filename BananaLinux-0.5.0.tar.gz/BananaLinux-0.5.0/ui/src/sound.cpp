#include "sound.h"
#include "../rnds/RndsUI.h"
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstring>
#ifdef BANANA_ALSA
#include <alsa/asoundlib.h>
#include <sys/stat.h>
#endif

namespace banana
{
	// 16-bit PCM WAV only (what rnds/gen_sounds.py writes)
	static bool loadWav(const std::string& path, std::vector<int16_t>& pcm, int& rate, int& channels)
	{
		FILE* f = fopen(path.c_str(), "rb");
		if (!f) return false;
		std::vector<uint8_t> b;
		uint8_t buf[4096];
		size_t n;
		while ((n = fread(buf, 1, sizeof buf, f)) > 0) b.insert(b.end(), buf, buf + n);
		fclose(f);
		if (b.size() < 44 || memcmp(b.data(), "RIFF", 4) || memcmp(b.data() + 8, "WAVE", 4)) return false;
		size_t at = 12;
		int bits = 0;
		while (at + 8 <= b.size())
		{
			uint32_t len = b[at + 4] | (b[at + 5] << 8) | (b[at + 6] << 16) | ((uint32_t)b[at + 7] << 24);
			const uint8_t* c = b.data() + at + 8;
			if (!memcmp(b.data() + at, "fmt ", 4) && len >= 16)
			{
				channels = c[2] | (c[3] << 8);
				rate = c[4] | (c[5] << 8) | (c[6] << 16) | (c[7] << 24);
				bits = c[14] | (c[15] << 8);
			}
			else if (!memcmp(b.data() + at, "data", 4))
			{
				if (bits != 16 || channels < 1) return false;
				len = (uint32_t)std::min<size_t>(len, b.size() - at - 8);
				pcm.resize(len / 2);
				memcpy(pcm.data(), c, pcm.size() * 2);
				return true;
			}
			at += 8 + len + (len & 1);
		}
		return false;
	}

#ifdef BANANA_ALSA
	// The menu plays on the same device as the games, and the RG DS Plus's amplifier is a 48 kHz part: anything else
	// is resampled there by alsa-lib's linear converter (the image has no speexrate). Convert each clip once, here,
	// so the stream is always 48 kHz and no plug resampler is involved.
	static void to48k(std::vector<int16_t>& pcm, int& rate, int channels)
	{
		if (rate == 48000 || channels < 1 || pcm.size() / channels < 2) return;
		size_t frames = pcm.size() / channels, n = (size_t)((double)frames * 48000 / rate);
		std::vector<int16_t> out(n * channels);
		for (size_t i = 0; i < n; i++)
		{
			double x = (double)i * rate / 48000;
			size_t j = (size_t)x;
			double f = x - j;
			if (j + 1 >= frames) { j = frames - 2; f = 1; }
			for (int c = 0; c < channels; c++)
				out[i * channels + c] = (int16_t)(pcm[j * channels + c] + (pcm[(j + 1) * channels + c] - pcm[j * channels + c]) * f);
		}
		pcm.swap(out);
		rate = 48000;
	}
#endif

	Sound::Sound(const std::string& dir)
	{
		for (const char* n : { "scroll", "select", "back", "fav", "ready", "insert" })
		{
			// a user theme's own sound for it (rnds::themeFiles; "off": none), else the theme's (one that doesn't
			// load: the theme's)
			auto own = rnds::themeFiles.sounds.find(n);
			if (own != rnds::themeFiles.sounds.end() && own->second == "off") continue;
			Clip c;
			bool got = own != rnds::themeFiles.sounds.end() && loadWav(own->second, c.pcm, c.rate, c.channels);
			if (!got) got = loadWav(dir + "/" + n + ".wav", c.pcm, c.rate, c.channels);
			if (got)
			{
#ifdef BANANA_ALSA
				to48k(c.pcm, c.rate, c.channels);
#endif
				clips[n] = std::move(c);
			}
		}
		th = std::thread([this] { run(); });
	}

	Sound::~Sound()
	{
		{
			std::lock_guard<std::mutex> l(m);
			stop = true;
		}
		cv.notify_all();
		if (th.joinable()) th.join();
	}

	void Sound::play(const std::string& name, bool closeAfter)
	{
		if (!enabled || !clips.count(name)) return;
		{
			std::lock_guard<std::mutex> l(m);
			queued = name;
			closeAfterQueued = closeAfter;
		}
		cv.notify_all();
	}

	void Sound::release(bool wait)
	{
		{
			std::lock_guard<std::mutex> l(m);
			closeNow = true;
			queued.clear();
		}
		cv.notify_all();
		if (!wait) return;
		// wait until the device is closed
		for (int i = 0; i < 100; i++)
		{
			{
				std::lock_guard<std::mutex> l(m);
				if (!closeNow) return;
			}
			std::this_thread::sleep_for(std::chrono::milliseconds(5));
		}
	}

	void Sound::run()
	{
#ifdef BANANA_ALSA
		// While the device is open the stream never stops: after a sound, silence follows, until QUIET with nothing to
		// play. The RG DS Plus's speaker amplifiers (aw88166) are started by their driver when the stream powers up,
		// and the first try fails because the I2S clock isn't running yet; the next try is ~0.4 s later and finds no
		// clock either if a short click has already ended, so an amplifier gave up for the whole time the device was
		// open (one speaker, or none). A running stream lets the retry find its clock. Writing 10 ms at a time also
		// lets a new sound cut the one playing (a held direction scrolls fast) within the 30 ms buffer.
		const auto QUIET = std::chrono::seconds(20);
		snd_pcm_t* pcm = nullptr;
		int openRate = 0, openCh = 0;
		std::vector<int16_t> silence;
		auto closeDev = [&] { if (pcm) { snd_pcm_drop(pcm); snd_pcm_close(pcm); pcm = nullptr; } };
		// Where sound plays (speakers or headphones) is bananad's /run/banana/asound.conf, which it replaces when the
		// jack changes. alsa-lib reads its configuration once per process (a file it loaded through a hook, as
		// /etc/asound.conf is, isn't looked at again), so a change means: close, forget the configuration, open again.
		auto routeId = [] { struct stat st; return stat("/run/banana/asound.conf", &st) ? 0LL : (long long)st.st_ino * 1000003LL + st.st_mtim.tv_sec * 1000000000LL + st.st_mtim.tv_nsec; };
		long long routeLoaded = routeId();
		int routeCheck = 0;
		const Clip* cur = nullptr;
		size_t at = 0;			// cur's next frame
		// the sound cur cut in on, when cur is a launch's last cue (the cartridge's click): played on under it to its end
		// instead of cut off. A starts the launch with the "ready" chime (0.46 s) and the click comes ~140 ms later since
		// the insert plays 3x as fast (0.5.0): the chime was cut off after a third of it (QA #12)
		const Clip* under = nullptr;
		size_t underAt = 0;
		std::vector<int16_t> mixed;
		bool closeAfter = false;	// cur was a launch's last cue: the device closes once it has played out
		int tail = -1;			// then the 10 ms blocks of silence still to write before the close
		// (150 ms: ALSA's 30 ms buffer and what the speaker amplifiers keep after it, so the chime's end is heard; the
		// launch's own close cut it off, testers said)
		const int TAIL = 15;
		bool closing = false;	// release() asked while a sound played: the close once it has played out
		auto lastSound = std::chrono::steady_clock::now();
		for (;;)
		{
			std::string name;
			{
				std::unique_lock<std::mutex> l(m);
				if (!pcm) cv.wait(l, [this] { return stop || closeNow || !queued.empty(); });	// closed: nothing to do
				if (stop) break;
				if (closeNow)	// a game is starting: the device closed, after the sound still playing (the chime)
				{
					if (pcm && (cur || under || tail > 0)) closing = true;
					else { closeDev(); cur = under = nullptr; tail = -1; closeAfter = closing = false; closeNow = false; continue; }
				}
				name = queued;
				queued.clear();
				if (!name.empty()) { closeAfter = closeAfterQueued; tail = -1; }
			}
			if (name.empty() && !cur && !under && tail == 0)
			{
				closeDev();
				tail = -1;
				closeAfter = closing = false;
				std::lock_guard<std::mutex> l(m);
				closeNow = false;
				continue;
			}
			auto now = std::chrono::steady_clock::now();
			if (!name.empty())
			{
				const Clip& c = clips[name];
				// (only a launch's cue plays over the sound before it; any other cuts it, as a held direction's scroll must)
				bool keep = closeAfter && cur && pcm && openRate == c.rate && openCh == c.channels;
				if (keep) { under = cur; underAt = at; }
				else under = nullptr;
				if (pcm && (openRate != c.rate || openCh != c.channels)) closeDev();
				if (!pcm)
				{
					if (long long r = routeId(); r != routeLoaded) { snd_config_update_free_global(); routeLoaded = r; }
					if (snd_pcm_open(&pcm, "default", SND_PCM_STREAM_PLAYBACK, 0) < 0) { pcm = nullptr; continue; }
					if (snd_pcm_set_params(pcm, SND_PCM_FORMAT_S16_LE, SND_PCM_ACCESS_RW_INTERLEAVED, c.channels, c.rate, 1, 30000) < 0)
					{
						snd_pcm_close(pcm); pcm = nullptr; continue;
					}
					openRate = c.rate; openCh = c.channels;
					silence.assign((size_t)(openRate / 100) * openCh, 0);
				}
				cur = &c;
				at = 0;
				lastSound = now;
			}
			else if (!cur && !under && now - lastSound >= QUIET) { closeDev(); continue; }
			// the jack changed while the stream runs (every 250 ms): the next sound opens where sound plays now
			if (++routeCheck >= 25) { routeCheck = 0; if (routeId() != routeLoaded) { closeDev(); cur = under = nullptr; continue; } }
			// the next 10 ms: the sound's, or silence
			const int16_t* p = silence.data();
			snd_pcm_sframes_t frames = (snd_pcm_sframes_t)(silence.size() / openCh);
			if (cur && !under)
			{
				size_t total = cur->pcm.size() / openCh;
				frames = (snd_pcm_sframes_t)std::min<size_t>((size_t)frames, total - at);
				p = cur->pcm.data() + at * openCh;
				at += (size_t)frames;
				if (at >= total) { cur = nullptr; lastSound = now; if (closeAfter || closing) tail = TAIL; }
			}
			else if (cur || under)
			{
				// both: summed (clipped) over the longer of what is left of them in this block
				std::vector<int32_t> acc(silence.size(), 0);
				size_t n = 0;
				auto add = [&](const Clip*& c, size_t& a)
				{
					if (!c) return;
					size_t total = c->pcm.size() / openCh, k = std::min<size_t>((size_t)frames, total - a);
					for (size_t i = 0; i < k * openCh; i++) acc[i] += c->pcm[a * openCh + i];
					a += k; n = std::max(n, k);
					if (a >= total) c = nullptr;
				};
				add(cur, at);
				add(under, underAt);
				mixed.resize(n * openCh);
				for (size_t i = 0; i < mixed.size(); i++) mixed[i] = (int16_t)std::min(32767, std::max(-32768, acc[i]));
				p = mixed.data();
				frames = (snd_pcm_sframes_t)n;
				if (!cur && !under) { lastSound = now; if (closeAfter || closing) tail = TAIL; }
			}
			else if (tail > 0) tail--;
			while (frames > 0)
			{
				snd_pcm_sframes_t w = snd_pcm_writei(pcm, p, (snd_pcm_uframes_t)frames);	// blocks while the buffer is full
				if (w < 0) { if (snd_pcm_recover(pcm, (int)w, 1) < 0) { closeDev(); cur = under = nullptr; break; } continue; }
				frames -= w; p += w * openCh;
			}
		}
		closeDev();
#else
		std::unique_lock<std::mutex> l(m);
		for (;;)
		{
			cv.wait(l, [this] { return stop || closeNow || !queued.empty(); });
			if (stop) break;
			closeNow = false;
			queued.clear();
		}
#endif
	}
}
