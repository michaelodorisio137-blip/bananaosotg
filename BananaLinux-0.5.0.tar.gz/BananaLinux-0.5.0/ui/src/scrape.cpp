// banana-scrape: box art, title screens, genres and years for the games on the card, from libretro's free
// collections (no account): libretro-thumbnails (thumbnails.libretro.com: <System>/Named_Boxarts and Named_Titles,
// PNGs named after the No-Intro/Redump names) and libretro-database's metadat (genre and releaseyear DATs). Written
// where the menu's library looks (library.cpp): <system folder>/media/box/<rom name>.jpg (the cover),
// media/label/<rom name>.jpg (the title screen, the cartridge label's art), and the genre and year as a game entry in
// the folder's gamelist.xml (added to one that is there; entries already in it are left alone).
//   banana-scrape [--force]     --force fetches again what is already there
// Progress in /run/banana/scrape.status, one line: "running <done> <total> <system name>|<game>", then
// "done <found> <total>" or "error <why>". A game whose name doesn't match any of the collection's is skipped.
// A game's own match (#28, the game page's Box art: a translation, a hack, another region's name):
//   banana-scrape --search <system> <words>          the collection's names that fit, best first: "NAME\t<name>" lines
//   banana-scrape --match <system> <rom> <name>      that name's cover and title screen for the game, kept in
//                                                    banana/boxart-match.tsv ("<system>/<file name without .ext>\t<name>"),
//                                                    which every scrape after looks in first
// Names are matched on letters and digits only, the bracketed tags left out, preferring the file's own region.
#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#define STBI_ONLY_JPEG
#include "../third_party/stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "../third_party/stb_image_write.h"
#include <algorithm>
#include <atomic>
#include <cctype>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <dlfcn.h>
#include <fstream>
#include <map>
#include <mutex>
#include <set>
#include <sstream>
#include <string>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>
#include <vector>

namespace
{
	// ---- libcurl, dlopen()ed as banana-ui does it ------------------------------------------------------------------
	struct Curl
	{
		void* (*init)(void) = nullptr;
		int (*setopt)(void*, int, ...) = nullptr;
		int (*perform)(void*) = nullptr;
		int (*getinfo)(void*, int, ...) = nullptr;
		void (*cleanup)(void*) = nullptr;
		char* (*escape)(void*, const char*, int) = nullptr;
		void (*freep)(void*) = nullptr;
		void* (*slistAppend)(void*, const char*) = nullptr;
		void (*slistFree)(void*) = nullptr;
		bool load()
		{
			void* l = dlopen("libcurl.so.4", RTLD_NOW | RTLD_LOCAL);
			if (!l) return false;
			init = (void* (*)(void))dlsym(l, "curl_easy_init");
			setopt = (int (*)(void*, int, ...))dlsym(l, "curl_easy_setopt");
			perform = (int (*)(void*))dlsym(l, "curl_easy_perform");
			getinfo = (int (*)(void*, int, ...))dlsym(l, "curl_easy_getinfo");
			cleanup = (void (*)(void*))dlsym(l, "curl_easy_cleanup");
			escape = (char* (*)(void*, const char*, int))dlsym(l, "curl_easy_escape");
			freep = (void (*)(void*))dlsym(l, "curl_free");
			slistAppend = (void* (*)(void*, const char*))dlsym(l, "curl_slist_append");
			slistFree = (void (*)(void*))dlsym(l, "curl_slist_free_all");
			return init && setopt && perform && getinfo && cleanup && escape && freep && slistAppend && slistFree;
		}
	} cu;
	size_t onBody(char* p, size_t sz, size_t n, void* u) { ((std::string*)u)->append(p, sz * n); return sz * n; }
	// the body of a GET, "" unless it answered 200. One handle per thread, kept: its connection is reused (the
	// thumbnails' server is far and slow to greet; a new TLS connection for every picture took seconds each)
	std::string get(const std::string& url, const std::vector<std::string>& headers = {})
	{
		thread_local void* h = nullptr;
		if (!h) h = cu.init();
		if (!h) return "";
		enum { WRITEDATA = 10001, URL = 10002, USERAGENT = 10018, WRITEFUNCTION = 20011, TIMEOUT = 13, NOSIGNAL = 99,
			FOLLOWLOCATION = 52, HTTPHEADER = 10023, RESPONSE_CODE = 0x200002 };
		std::string body;
		long status = 0;
		cu.setopt(h, URL, url.c_str());
		cu.setopt(h, USERAGENT, "BananaOS banana-scrape (+https://github.com/JorreFog/BananaLinux)");
		cu.setopt(h, NOSIGNAL, 1L);
		cu.setopt(h, TIMEOUT, 60L);
		cu.setopt(h, FOLLOWLOCATION, 1L);
		cu.setopt(h, WRITEFUNCTION, onBody);
		cu.setopt(h, WRITEDATA, &body);
		void* hl = nullptr;
		for (auto& x : headers) hl = cu.slistAppend(hl, x.c_str());
		cu.setopt(h, HTTPHEADER, hl);	// (none: nullptr, the handle's headers cleared for the next GET)
		bool ok = cu.perform(h) == 0;
		if (hl) cu.slistFree(hl);
		if (ok) cu.getinfo(h, RESPONSE_CODE, &status);
		if (!ok) { cu.cleanup(h); h = nullptr; }	// (a fresh one next time)
		return ok && status == 200 ? body : "";
	}
	std::string esc(const std::string& s)
	{
		void* h = cu.init();
		char* e = cu.escape(h, s.c_str(), (int)s.size());
		std::string r = e ? e : s;
		if (e) cu.freep(e);
		cu.cleanup(h);
		return r;
	}

	// ---- names ----------------------------------------------------------------------------------------------------
	std::string lower(std::string s) { for (auto& c : s) c = (char)tolower((unsigned char)c); return s; }
	// letters and digits only, the (tags) and [tags] left out (and &: the thumbnails write it "_"): "Pokemon - HeartGold Version (USA)" and
	// "Pokemon HeartGold Version" are the same game
	std::string norm(const std::string& s)
	{
		std::string r;
		int depth = 0;
		for (size_t i = 0; i < s.size(); i++)
		{
			char c = s[i];
			if (c == '(' || c == '[') { depth++; continue; }
			if (c == ')' || c == ']') { if (depth) depth--; continue; }
			if (depth) continue;
			if (isalnum((unsigned char)c)) r += (char)tolower((unsigned char)c);	// (& is "_" in the thumbnails' names: left out)
		}
		return r;
	}
	// the same name with its words in any order and "the" left out: "The Legend of Zelda Ocarina of Time" and
	// "Legend of Zelda, The - Ocarina of Time", "007 GoldenEye" and "GoldenEye 007" (tried when norm() finds nothing)
	std::string words(const std::string& s)
	{
		std::vector<std::string> w;
		std::string cur;
		int depth = 0;
		for (size_t i = 0; i <= s.size(); i++)
		{
			char c = i < s.size() ? s[i] : ' ';
			if (c == '(' || c == '[') { depth++; continue; }
			if (c == ')' || c == ']') { if (depth) depth--; continue; }
			if (depth) continue;
			if (isalnum((unsigned char)c)) { cur += (char)tolower((unsigned char)c); continue; }
			if (c == '\'') continue;	// (Mario's, Marios)
			if (!cur.empty() && cur != "the") w.push_back(cur);
			cur.clear();
		}
		std::sort(w.begin(), w.end());
		std::string r;
		for (auto& x : w) r += x + " ";
		return r;
	}
	// how well a collection name fits the file's: its region when the file names one, else the usual preference
	int score(const std::string& cand, const std::string& file)
	{
		std::string c = lower(cand), f = lower(file);
		int s = 0;
		for (const char* r : { "usa", "europe", "japan", "world", "australia", "germany", "france", "spain", "italy" })
			if (f.find(r) != std::string::npos && c.find(r) != std::string::npos) s += 10;
		if (c.find("usa") != std::string::npos) s += 4;
		if (c.find("world") != std::string::npos) s += 4;
		if (c.find("europe") != std::string::npos) s += 2;
		for (const char* bad : { "beta", "proto", "demo", "kiosk", "sample", "virtual console", "switch online", "aftermarket", "unl)" })
			if (c.find(bad) != std::string::npos) s -= 20;
		if (c.find("(rev") != std::string::npos) s -= 1;
		return s;
	}
	// the PNG names in an Apache index page (href="...png", %-encoded)
	std::vector<std::string> indexNames(const std::string& html)
	{
		std::vector<std::string> out;
		size_t at = 0;
		while ((at = html.find("href=\"", at)) != std::string::npos)
		{
			at += 6;
			size_t e = html.find('"', at);
			if (e == std::string::npos) break;
			std::string h = html.substr(at, e - at);
			at = e;
			if (h.size() < 5 || lower(h.substr(h.size() - 4)) != ".png" || h.find('/') != std::string::npos) continue;
			std::string d;
			for (size_t i = 0; i < h.size(); i++)
			{
				if (h[i] == '%' && i + 2 < h.size()) { d += (char)strtol(h.substr(i + 1, 2).c_str(), nullptr, 16); i += 2; }
				else d += h[i];
			}
			d.resize(d.size() - 4);
			for (const char* ent : { "&amp;" }) { size_t p; while ((p = d.find(ent)) != std::string::npos) d.replace(p, 5, "&"); }
			out.push_back(d);
		}
		return out;
	}
	// a metadat DAT's games: name -> the field's value (genre "Role-Playing", releaseyear "2009")
	std::map<std::string, std::string> datField(const std::string& dat, const char* field)
	{
		std::map<std::string, std::string> out;
		std::istringstream in(dat);
		std::string ln, name, key = std::string(field) + " \"";
		while (std::getline(in, ln))
		{
			size_t a = ln.find_first_not_of(" \t");
			if (a == std::string::npos) continue;
			// the game's name: "comment" in libretro-database's metadat, "name" in other DATs
			if (!ln.compare(a, 9, "comment \"")) { size_t e = ln.find('"', a + 9); if (e != std::string::npos) name = ln.substr(a + 9, e - a - 9); }
			else if (!ln.compare(a, 6, "name \"") && name.empty()) { size_t e = ln.find('"', a + 6); if (e != std::string::npos) name = ln.substr(a + 6, e - a - 6); }
			else if (!ln.compare(a, key.size(), key) && !name.empty())
			{
				size_t e = ln.find('"', a + key.size());
				if (e != std::string::npos) { std::string v = ln.substr(a + key.size(), e - a - key.size()); out.emplace(norm(name), v); out.emplace(words(name), v); }
			}
			else if (ln[a] == ')') name.clear();
		}
		return out;
	}

	// ---- pictures: decoded, made no larger than max x max (area average), written as PNG ---------------------------
	bool savePicture(const std::string& data, const std::string& path, int max)
	{
		int w, h, n;
		unsigned char* px = stbi_load_from_memory((const unsigned char*)data.data(), (int)data.size(), &w, &h, &n, 4);
		if (!px) return false;
		double k = std::min(1.0, std::min((double)max / w, (double)max / h));
		int ow = std::max(1, (int)(w * k + 0.5)), oh = std::max(1, (int)(h * k + 0.5));
		std::vector<unsigned char> out((size_t)ow * oh * 4);
		for (int y = 0; y < oh; y++)
		{
			int y0 = y * h / oh, y1 = std::max(y0 + 1, (y + 1) * h / oh);
			for (int x = 0; x < ow; x++)
			{
				int x0 = x * w / ow, x1 = std::max(x0 + 1, (x + 1) * w / ow);
				unsigned s[4] = { 0, 0, 0, 0 }, c = 0;
				for (int yy = y0; yy < y1; yy++)
					for (int xx = x0; xx < x1; xx++, c++)
						for (int i = 0; i < 4; i++) s[i] += px[((size_t)yy * w + xx) * 4 + i];
				for (int i = 0; i < 4; i++) out[((size_t)y * ow + x) * 4 + i] = (unsigned char)(s[i] / c);
			}
		}
		stbi_image_free(px);
		// JPEG (quality 90, over black where the picture had transparency): a PNG's compression took most of a second
		// a picture on these cores, and the JPEG is a third of the size on the card
		for (size_t i = 0; i < out.size(); i += 4) { unsigned a = out[i + 3]; for (int c = 0; c < 3; c++) out[i + c] = (unsigned char)(out[i + c] * a / 255); }
		std::vector<unsigned char> rgb((size_t)ow * oh * 3);
		for (size_t i = 0, j = 0; i < out.size(); i += 4, j += 3) { rgb[j] = out[i]; rgb[j + 1] = out[i + 1]; rgb[j + 2] = out[i + 2]; }
		std::string tmp = path + ".part";
		bool ok = stbi_write_jpg(tmp.c_str(), ow, oh, 3, rgb.data(), 90) != 0;
		return ok && rename(tmp.c_str(), path.c_str()) == 0;
	}

	// ---- the card ---------------------------------------------------------------------------------------------------
	struct System { std::string id, name, folder; std::vector<std::string> exts; };
	const std::map<std::string, std::string> LIBRETRO = {
		{ "nds", "Nintendo - Nintendo DS" }, { "gba", "Nintendo - Game Boy Advance" }, { "gbc", "Nintendo - Game Boy Color" },
		{ "gb", "Nintendo - Game Boy" }, { "nes", "Nintendo - Nintendo Entertainment System" },
		{ "snes", "Nintendo - Super Nintendo Entertainment System" }, { "megadrive", "Sega - Mega Drive - Genesis" },
		{ "psx", "Sony - PlayStation" }, { "n64", "Nintendo - Nintendo 64" } };
	std::vector<System> systems(const std::string& conf)
	{
		std::vector<System> out;
		std::ifstream f(conf);
		std::string ln;
		System* cur = nullptr;
		while (std::getline(f, ln))
		{
			if (ln.empty() || ln[0] == '#') continue;
			if (ln[0] == '[') { out.push_back(System()); cur = &out.back(); cur->id = ln.substr(1, ln.find(']') - 1); cur->folder = cur->id; continue; }
			size_t eq = ln.find('=');
			if (!cur || eq == std::string::npos) continue;
			std::string k = ln.substr(0, eq), v = ln.substr(eq + 1);
			k.erase(k.find_last_not_of(" \t") + 1);
			v.erase(0, v.find_first_not_of(" \t"));
			if (k == "name") cur->name = v;
			else if (k == "folder") cur->folder = v;
			else if (k == "ext") { std::istringstream e(v); std::string x; while (e >> x) cur->exts.push_back(lower(x)); }
		}
		return out;
	}
	void listRoms(const std::string& dir, const std::string& rel, const std::vector<std::string>& exts, std::vector<std::string>& out, int depth)
	{
		DIR* d = opendir(dir.c_str());
		if (!d) return;
		while (dirent* e = readdir(d))
		{
			std::string n = e->d_name;
			if (n.empty() || n[0] == '.' || n == "media") continue;
			std::string p = dir + "/" + n, r = rel.empty() ? n : rel + "/" + n;
			struct stat st;
			if (stat(p.c_str(), &st) != 0) continue;
			if (S_ISDIR(st.st_mode)) { if (depth < 2) listRoms(p, r, exts, out, depth + 1); continue; }
			std::string ln = lower(n);
			for (auto& x : exts)
				if (ln.size() > x.size() + 1 && ln.compare(ln.size() - x.size() - 1, std::string::npos, "." + x) == 0) { out.push_back(r); break; }
		}
		closedir(d);
	}
	std::string xmlEsc(const std::string& s)
	{
		std::string r;
		for (char c : s)
			switch (c) { case '&': r += "&amp;"; break; case '<': r += "&lt;"; break; case '>': r += "&gt;"; break; case '"': r += "&quot;"; break; default: r += c; }
		return r;
	}

	std::mutex mu;
	std::string statusLine;
	void status(const std::string& s)
	{
		std::lock_guard<std::mutex> l(mu);
		if (s == statusLine) return;
		statusLine = s;
		if (getenv("BANANA_SCRAPE_VERBOSE")) fprintf(stderr, "%s\n", s.c_str());
		std::string tmp = "/run/banana/scrape.status.new";
		if (FILE* f = fopen(tmp.c_str(), "w")) { fprintf(f, "%s\n", s.c_str()); fclose(f); rename(tmp.c_str(), "/run/banana/scrape.status"); }
	}
	// ---- TwilightBoxart (KirovAir/TwilightBoxart, an open API for thin clients: a DS on Wi-Fi among them) ---------
	// GET <base>/v2/art.png?name=<file name>&header=<base64 of its first 512 bytes>: PNG bytes, or an empty 404 when it
	// doesn't know the game. Someone's own server, so asked politely: one request a second at most, whichever thread
	// asks, and a game it didn't know isn't asked about again (banana/cache/twilight-miss.txt) unless --force.
	// /v2 wants its X-Twilight-Key header (401 without it): settings.conf's boxart_twilight_key, its public client key by default.
	std::string b64(const std::string& in)
	{
		static const char* T = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
		std::string r;
		for (size_t i = 0; i < in.size(); i += 3)
		{
			unsigned v = (unsigned char)in[i] << 16 | (i + 1 < in.size() ? (unsigned char)in[i + 1] << 8 : 0) | (i + 2 < in.size() ? (unsigned char)in[i + 2] : 0);
			r += T[v >> 18 & 63]; r += T[v >> 12 & 63];
			r += i + 1 < in.size() ? T[v >> 6 & 63] : '=';
			r += i + 2 < in.size() ? T[v & 63] : '=';
		}
		return r;
	}
	std::string twilightArt(const std::string& base, const std::string& key, const std::string& path)
	{
		static std::mutex m;
		static auto last = std::chrono::steady_clock::now() - std::chrono::seconds(1);
		std::string fname = path.substr(path.rfind('/') + 1), ext = lower(fname.substr(fname.rfind('.') + 1));
		std::string url = base + "/v2/art.png?w=256&h=192&name=" + esc(fname);	// (the largest its API documents)
		if (ext != "zip" && ext != "7z")	// (an archive's first bytes are the archive's, not the game's)
		{
			std::ifstream f(path, std::ios::binary);
			char hdr[512];
			f.read(hdr, sizeof hdr);
			if (f.gcount() > 0) url += "&header=" + esc(b64(std::string(hdr, (size_t)f.gcount())));
		}
		std::lock_guard<std::mutex> l(m);
		std::this_thread::sleep_until(last + std::chrono::seconds(1));
		last = std::chrono::steady_clock::now();
		// its key isn't a secret (its web client and repository carry it): it marks a client written against the API
		return get(url, { "X-Twilight-Key: " + key, "X-Twilight-Client: BananaOS/banana-scrape" });
	}
}

int main(int argc, char** argv)
{
	bool force = argc > 1 && !strcmp(argv[1], "--force");
	// Settings > System > Box art from (settings.conf's boxart_source): libretro (libretro-thumbnails), both
	// (libretro, then TwilightBoxart for the covers it has none of) or twilight (TwilightBoxart first, libretro for the
	// rest); TwilightBoxart's server in boxart_twilight_url
	auto setting = [](const char* key, const std::string& def)
	{
		std::string r = def, ln;
		for (const char* path : { "/etc/banana/settings.conf", "/data/banana/settings.conf" })
		{
			std::ifstream f(path);
			while (std::getline(f, ln))
			{
				size_t eq = ln.find('=');
				if (ln.empty() || ln[0] == '#' || eq == std::string::npos) continue;
				std::string k = ln.substr(0, eq), v = ln.substr(eq + 1);
				k.erase(k.find_last_not_of(" \t") + 1);
				v.erase(0, v.find_first_not_of(" \t")); v.erase(v.find_last_not_of(" \t\r") + 1);
				if (k == key) r = v;
			}
		}
		return r;
	};
	std::string source = setting("boxart_source", "libretro"), twilight = setting("boxart_twilight_url", "https://boxart.kirovair.com");
	std::string twilightKey = setting("boxart_twilight_key", "tb2_9f4c1d7a3e8b5062");
	while (!twilight.empty() && twilight.back() == '/') twilight.pop_back();
	if (source != "both" && source != "twilight") twilight.clear();
	// (the systems TwilightBoxart knows: Nintendo's handhelds and consoles, Sega's 8 and 16-bit)
	const std::set<std::string> TWILIGHT = { "nds", "gba", "gbc", "gb", "nes", "snes", "megadrive", "n64" };
	std::set<std::string> misses;
	std::mutex missMu;
	const std::string MISSES = "/data/banana/cache/twilight-miss.txt";
	if (!twilight.empty() && !force)
	{
		std::ifstream f(MISSES);
		for (std::string ln; std::getline(f, ln);) misses.insert(ln);
	}
	const char* roms = getenv("BANANA_ROMS") ? getenv("BANANA_ROMS") : "/data/roms";
	// the merged list banana-ui-session made (systems-merge: the card's systems.conf over the image's), never the card's
	// file alone
	std::string conf = getenv("BANANA_SYSTEMS") ? getenv("BANANA_SYSTEMS") :
		access("/run/banana/systems.conf", R_OK) == 0 ? "/run/banana/systems.conf" : "/etc/banana/systems.conf";
	const std::string MATCHES = "/data/banana/boxart-match.tsv";
	if (argc >= 4 && (!strcmp(argv[1], "--search") || !strcmp(argv[1], "--match")))
	{
		bool match = !strcmp(argv[1], "--match");
		if (match && argc < 5) return 2;
		if (!cu.load()) { printf("ERROR libcurl is missing\n"); return 1; }
		std::string base, sysFolder;
		for (auto& sys : systems(conf))
			if (sys.id == argv[2])
			{
				auto lr = LIBRETRO.find(sys.id);
				if (lr != LIBRETRO.end()) base = "https://thumbnails.libretro.com/" + esc(lr->second) + "/";
				sysFolder = sys.folder;
			}
		if (base.empty()) { printf("ERROR libretro has no covers for this system\n"); return 1; }
		if (!match)
		{
			std::string idx = get(base + "Named_Boxarts/");
			if (idx.empty()) { printf("ERROR no connection\n"); return 1; }
			// the words typed, each found in a name (as a whole word: a point, as the start of one: half), the names
			// with the most first, then as the scrape prefers them (the USA's, the world's, Europe's; demos and betas
			// last), then the shortest (fewer words besides)
			std::vector<std::string> want;
			{ std::istringstream in(words(argv[3])); std::string w; while (in >> w) want.push_back(w); }
			std::vector<std::pair<int, std::string>> hits;
			for (auto& n : indexNames(idx))
			{
				std::vector<std::string> have;
				{ std::istringstream in(words(n)); std::string w; while (in >> w) have.push_back(w); }
				int pts = 0;
				for (auto& w : want)
				{
					int best = 0;
					for (auto& h : have) best = std::max(best, h == w ? 2 : h.compare(0, w.size(), w) == 0 ? 1 : 0);
					pts += best;
				}
				// the letters typed, in a row, inside the name's ("fire red" in "FireRed Version"): as if every word fit
				std::string q = norm(argv[3]);
				if (q.size() >= 3 && norm(n).find(q) != std::string::npos) pts = std::max(pts, (int)want.size() * 2 + 1);
				if (pts == 0) continue;
				hits.push_back({ pts * 100000 + score(n, argv[3]) * 100 - (int)have.size(), n });
			}
			std::stable_sort(hits.begin(), hits.end(), [](const auto& a, const auto& b) { return a.first > b.first; });
			for (size_t i = 0; i < hits.size() && i < 40; i++) printf("NAME\t%s\n", hits[i].second.c_str());
			return 0;
		}
		// the game's cover and title screen from that name, over what it had
		std::string rom = argv[3], name = argv[4];
		size_t sl = rom.rfind('/');
		std::string dir = sl == std::string::npos ? "." : rom.substr(0, sl), file = rom.substr(sl == std::string::npos ? 0 : sl + 1);
		// the art goes in the system's folder (on whichever card the game is), where the library and the full scrape
		// look, also for a game in a folder of its own (nds/Hacks/Foo.nds: nds/media/box/Foo.jpg)
		{
			std::vector<std::string> sysDirs;
			if (!sysFolder.empty() && sysFolder[0] == '/') sysDirs.push_back(sysFolder);
			else
			{
				sysDirs.push_back(std::string(roms) + "/" + sysFolder);
				std::ifstream f(getenv("BANANA_SD2") ? getenv("BANANA_SD2") : "/run/banana/sd2/roms");
				std::string ln;
				if (std::getline(f, ln))
				{
					ln.erase(0, ln.find_first_not_of(" \t\r\n")); ln.erase(ln.find_last_not_of(" \t\r\n") + 1);
					if (!ln.empty()) sysDirs.push_back(ln + "/" + sysFolder);
				}
			}
			for (auto& d : sysDirs) if (!d.empty() && rom.compare(0, d.size() + 1, d + "/") == 0) dir = d;
		}
		std::string stem = file.substr(0, file.rfind('.'));
		std::string box = get(base + "Named_Boxarts/" + esc(name) + ".png");
		if (box.empty()) { printf("ERROR no cover by that name\n"); return 1; }
		mkdir((dir + "/media").c_str(), 0755);
		mkdir((dir + "/media/box").c_str(), 0755);
		if (!savePicture(box, dir + "/media/box/" + stem + ".jpg", 512)) { printf("ERROR the card can't be written\n"); return 1; }
		unlink((dir + "/media/box/" + stem + ".png").c_str());	// (an older PNG would win over it)
		std::string title = get(base + "Named_Titles/" + esc(name) + ".png");
		if (!title.empty())
		{
			mkdir((dir + "/media/label").c_str(), 0755);
			if (savePicture(title, dir + "/media/label/" + stem + ".jpg", 320)) unlink((dir + "/media/label/" + stem + ".png").c_str());
		}
		// remembered, so a scrape with --force keeps it (the game's line replaced)
		std::string key = std::string(argv[2]) + "/" + stem, out, ln;
		{
			std::ifstream f(MATCHES);
			while (std::getline(f, ln)) if (ln.compare(0, key.size() + 1, key + "\t") != 0 && !ln.empty()) out += ln + "\n";
		}
		out += key + "\t" + name + "\n";
		std::string tmp = MATCHES + ".new";
		if (FILE* f = fopen(tmp.c_str(), "w")) { fwrite(out.data(), 1, out.size(), f); fflush(f); fsync(fileno(f)); fclose(f); rename(tmp.c_str(), MATCHES.c_str()); }
		sync();
		printf("OK%s\n", title.empty() ? " cover" : " cover title");
		return 0;
	}
	// bananad doesn't put the handheld to sleep for idleness while a scrape runs (its pid in /run/banana/awake.pid; not
	// for --search and --match above, which are short and would take the file away from a scrape running beside them)
	if (FILE* f = fopen("/run/banana/awake.pid", "w")) { fprintf(f, "%d\n", (int)getpid()); fclose(f); }
	struct Unlink { ~Unlink() { unlink("/run/banana/awake.pid"); } } awake;
	if (!cu.load()) { status("error libcurl is missing"); return 1; }
	if (get("https://thumbnails.libretro.com/").empty()) { status("error no connection"); return 1; }
	std::map<std::string, std::string> matches;	// the games' own matches (--match): "<system>/<stem>" -> name
	{
		std::ifstream f(MATCHES);
		for (std::string ln; std::getline(f, ln);) { size_t t = ln.find('\t'); if (t != std::string::npos) matches[ln.substr(0, t)] = ln.substr(t + 1); }
	}

	struct Job { System sys; std::string dir, rel, stem, box, title; };
	std::vector<Job> jobs;
	std::map<std::string, std::map<std::string, std::string>> genres, years;	// per system: norm name -> value
	int total = 0;
	// the card's roms folder, and the second card's while it's in (the RG DS Plus: the folder bananad's sd2 script
	// offers in /run/banana/sd2/roms, as the library reads it); its art goes on that card, beside its games
	std::vector<std::string> roots = { roms };
	{
		std::ifstream f(getenv("BANANA_SD2") ? getenv("BANANA_SD2") : "/run/banana/sd2/roms");
		std::string ln;
		if (std::getline(f, ln))
		{
			ln.erase(0, ln.find_first_not_of(" \t\r\n"));
			ln.erase(ln.find_last_not_of(" \t\r\n") + 1);
			if (!ln.empty() && ln != roms) roots.push_back(ln);
		}
	}
	for (auto& sys : systems(conf))
	{
		auto lr = LIBRETRO.find(sys.id);
		if (lr == LIBRETRO.end()) continue;
		std::vector<std::pair<std::string, std::vector<std::string>>> places;	// a folder and the games in it
		int count = 0;
		for (size_t ri = 0; ri < roots.size(); ri++)
		{
			if (ri > 0 && sys.folder[0] == '/') continue;	// an absolute folder: one place
			std::string dir = sys.folder[0] == '/' ? sys.folder : roots[ri] + "/" + sys.folder;
			std::vector<std::string> rels;
			listRoms(dir, "", sys.exts, rels, 0);
			count += (int)rels.size();
			if (!rels.empty()) places.push_back({ dir, rels });
		}
		if (places.empty()) continue;
		status("running 0 " + std::to_string(total + count) + " " + sys.name + "|the list of covers");
		// the collection's names, to match ours against
		std::string base = "https://thumbnails.libretro.com/" + esc(lr->second) + "/";
		std::vector<std::string> boxes = indexNames(get(base + "Named_Boxarts/")), titles = indexNames(get(base + "Named_Titles/"));
		std::map<std::string, std::vector<std::string>> byBox, byTitle, byBoxW, byTitleW;
		for (auto& n : boxes) { byBox[norm(n)].push_back(n); byBoxW[words(n)].push_back(n); }
		for (auto& n : titles) { byTitle[norm(n)].push_back(n); byTitleW[words(n)].push_back(n); }
		std::string meta = "https://raw.githubusercontent.com/libretro/libretro-database/master/metadat/";
		genres[sys.id] = datField(get(meta + "genre/" + esc(lr->second) + ".dat"), "genre");
		years[sys.id] = datField(get(meta + "releaseyear/" + esc(lr->second) + ".dat"), "releaseyear");
		auto best = [](const std::vector<std::string>& c, const std::string& stem)
		{
			std::string b;
			int bs = -1000;
			for (auto& n : c) { int s = score(n, stem); if (s > bs) { bs = s; b = n; } }
			return b;
		};
		for (auto& [dir, rels] : places)
		for (auto& rel : rels)
		{
			Job j;
			j.sys = sys; j.dir = dir; j.rel = rel;
			std::string fname = rel.substr(rel.rfind('/') == std::string::npos ? 0 : rel.rfind('/') + 1);
			j.stem = fname.substr(0, fname.rfind('.'));
			auto mi = matches.find(sys.id + "/" + j.stem);
			if (mi != matches.end())
			{
				j.box = base + "Named_Boxarts/" + esc(mi->second) + ".png";
				j.title = base + "Named_Titles/" + esc(mi->second) + ".png";
				jobs.push_back(j);
				continue;
			}
			std::string k = norm(j.stem), kw = words(j.stem);
			// the same name; the same words in another order; then, as a last try, one name the start of the other
			// ("Aero the Acro-Bat" and "Aero the Acro-Bat - Rascal Rival Revenge", "Rayman 3 - Hoodlum Havoc" and
			// "Rayman 3"), at least 8 letters, the closest in length
			auto find = [&](std::map<std::string, std::vector<std::string>>& by, std::map<std::string, std::vector<std::string>>& byW) -> const std::vector<std::string>*
			{
				auto a = by.find(k);
				if (a != by.end()) return &a->second;
				auto w = byW.find(kw);
				if (w != byW.end()) return &w->second;
				if (k.size() < 8) return nullptr;
				const std::vector<std::string>* bestV = nullptr;
				size_t bestD = 1000;
				for (auto it = by.lower_bound(k.substr(0, 8)); it != by.end() && it->first.compare(0, 8, k, 0, 8) == 0; ++it)
				{
					const std::string& c = it->first;
					bool pre = c.size() >= 8 && (c.compare(0, std::min(c.size(), k.size()), k, 0, std::min(c.size(), k.size())) == 0);
					if (!pre) continue;
					size_t d = c.size() > k.size() ? c.size() - k.size() : k.size() - c.size();
					if (d < bestD) { bestD = d; bestV = &it->second; }
				}
				return bestV;
			};
			if (auto v = find(byBox, byBoxW)) j.box = base + "Named_Boxarts/" + esc(best(*v, j.stem)) + ".png";
			if (auto v = find(byTitle, byTitleW)) j.title = base + "Named_Titles/" + esc(best(*v, j.stem)) + ".png";
			jobs.push_back(j);
		}
		total += count;
	}

	// the pictures, eight at a time (the time goes to waiting for the server, not the CPU)
	std::atomic<int> next{0}, done{0}, found{0};
	auto worker = [&]
	{
		for (int i; (i = next++) < (int)jobs.size();)
		{
			Job& j = jobs[i];
			std::string boxPath = j.dir + "/media/box/" + j.stem + ".jpg", labelPath = j.dir + "/media/label/" + j.stem + ".jpg";
			// (art from before, as PNG, counts as there)
			std::string boxPng = j.dir + "/media/box/" + j.stem + ".png", labelPng = j.dir + "/media/label/" + j.stem + ".png";
			bool got = false;
			bool tw = !twilight.empty() && TWILIGHT.count(j.sys.id);
			if (tw) { std::lock_guard<std::mutex> l(missMu); tw = !misses.count(j.sys.id + "/" + j.rel); }
			if (!j.box.empty() || tw)
			{
				if (!force && (access(boxPath.c_str(), F_OK) == 0 || access(boxPng.c_str(), F_OK) == 0)) got = true;
				else
				{
					mkdir((j.dir + "/media").c_str(), 0755);
					mkdir((j.dir + "/media/box").c_str(), 0755);
					std::string d;
					bool asked = false;
					if (tw && source == "twilight") { d = twilightArt(twilight, twilightKey, j.dir + "/" + j.rel); asked = true; }
					if (d.empty() && !j.box.empty()) d = get(j.box);
					if (d.empty() && tw && !asked) { d = twilightArt(twilight, twilightKey, j.dir + "/" + j.rel); asked = true; }
					if (asked && d.empty())
					{
						std::lock_guard<std::mutex> l(missMu);
						misses.insert(j.sys.id + "/" + j.rel);
					}
					got = !d.empty() && savePicture(d, boxPath, 512);
				}
			}
			if (!j.title.empty() && (force || (access(labelPath.c_str(), F_OK) != 0 && access(labelPng.c_str(), F_OK) != 0)))
			{
				mkdir((j.dir + "/media").c_str(), 0755);
				mkdir((j.dir + "/media/label").c_str(), 0755);
				std::string d = get(j.title);
				if (!d.empty()) savePicture(d, labelPath, 320);
			}
			if (got) found++;
			int n = ++done;
			status("running " + std::to_string(n) + " " + std::to_string(total) + " " + j.sys.name + "|" + j.stem);
		}
	};
	std::vector<std::thread> pool;
	for (int t = 0; t < 8; t++) pool.emplace_back(worker);
	for (auto& t : pool) t.join();
	if (!twilight.empty())
	{
		mkdir("/data/banana/cache", 0755);
		std::ofstream f(MISSES);
		for (auto& m : misses) f << m << "\n";
	}

	// genres and years into each folder's gamelist.xml (new entries only)
	std::map<std::string, std::vector<const Job*>> byDir;
	for (auto& j : jobs) byDir[j.dir].push_back(&j);
	for (auto& kv : byDir)
	{
		std::string path = kv.first + "/gamelist.xml", x;
		{ std::ifstream f(path); std::stringstream ss; ss << f.rdbuf(); x = ss.str(); }
		std::string add;
		for (const Job* j : kv.second)
		{
			if (x.find("<path>./" + xmlEsc(j->rel) + "</path>") != std::string::npos || x.find("<path>" + xmlEsc(j->rel) + "</path>") != std::string::npos) continue;
			std::string k = norm(j->stem), kw = words(j->stem), g, y;
			auto& G = genres[j->sys.id];
			auto& Y = years[j->sys.id];
			auto gi = G.find(k); if (gi == G.end()) gi = G.find(kw); if (gi != G.end()) g = gi->second;
			auto yi = Y.find(k); if (yi == Y.end()) yi = Y.find(kw); if (yi != Y.end()) y = yi->second;
			if (g.empty() && y.empty()) continue;
			add += "\t<game>\n\t\t<path>./" + xmlEsc(j->rel) + "</path>\n";
			if (!g.empty()) add += "\t\t<genre>" + xmlEsc(g) + "</genre>\n";
			if (y.size() == 4) add += "\t\t<releasedate>" + y + "0101T000000</releasedate>\n";
			add += "\t</game>\n";
		}
		if (add.empty()) continue;
		size_t end = x.rfind("</gameList>");
		// a list that is there but has no end we know (another tool's, cut short, unreadable): left as it is, not
		// replaced by one with only these games (the user's own entries would be lost)
		if (end == std::string::npos && (!x.empty() || access(path.c_str(), F_OK) == 0)) continue;
		if (end == std::string::npos) x = "<?xml version=\"1.0\"?>\n<gameList>\n" + add + "</gameList>\n";
		else x.insert(end, add);
		std::string tmp = path + ".new";
		if (FILE* f = fopen(tmp.c_str(), "w"))
		{
			bool ok = fwrite(x.data(), 1, x.size(), f) == x.size();
			ok &= fflush(f) == 0 && fsync(fileno(f)) == 0;
			ok &= fclose(f) == 0;
			if (!ok || rename(tmp.c_str(), path.c_str()) != 0) unlink(tmp.c_str());
		}
	}
	sync();
	status("done " + std::to_string(found.load()) + " " + std::to_string(total));
	return 0;
}
